  <aside id="jobs-with-clients" class="summary">
    <header>
      <h1>Job Opportunities with Our Clients</h1>
    </header>
    <ul>
      <li class="job">
        <span class="sector">Consumer:</span>
        <span class="title">Nike Expert IT Architect</span>
        <a href="#!http://careers.futurestep.com/jobs/nike-expert-it-architect" title="Read more about the job: Nike Expert IT Architect" rel="external">Read
          more</a>
      </li>
      <li class="job">
        <span class="sector">Technology:</span>
        <span class="title">Senior Development Manager</span>
        <a href="#!http://careers.futurestep.com/jobs/senior-development-manager" title="Read more about the job: Senior Development Manager" rel="external">Read
          more</a>
      </li>
      <li class="job">
        <span class="sector">Industrial:</span>
        <span class="title">Ore Reserves Geologist</span>
        <a href="#!http://careers.futurestep.com/jobs/ore-reserves-geologist" title="Read more about the job: Ore Reserves Geologist" rel="external">Read
          more</a>
      </li>
      <li class="job">
        <span class="sector">Health</span>
        <span class="title">Senior Marketing Manager to Director - Health Finance</span>
        <a href="#!http://careers.futurestep.com/jobs/senior-marketing-manager-to-director" title="Read more about the job: Senior Marketing Manager to Director - Health Finance" rel="external">Read
          more</a>
      </li>
      <li class="job">
        <span class="sector">Financial:</span>
        <span class="title">VP, Client Relations - Leading Financial Institutions</span>
        <a href="#!http://careers.futurestep.com/jobs/vp-client-relations" title="Read more about the job: VP, Client Relations - Leading Financial Institutions" rel="external">Read
          more</a>
      </li>
      <li>
        <a href="#!http://careers.futurestep.com/jobs/" title="View more opportunities" rel="external" class="more-info opportunities">View
          more
          opportunities &gt;</a>
      </li>
    </ul>
    <!--<div class="actions">-->
    <!--<a href="#!http://careers.futurestep.com/jobs/" title="View more opportunities" rel="external" class="more-info opportunities">View-->
    <!--more-->
    <!--opportunities &gt;</a>-->
    <!--</div>-->
  </aside>