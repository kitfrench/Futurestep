<?php
global $post;
$terms = get_the_terms( $post->ID, 'category-sector' );
$sector_links = array();
if($terms) {
    foreach ( $terms as $term ) {
		  $sector_links[] = $term->slug;
	   }
	  $sector = join( ", ", $sector_links );
	} else {
    $sector='';
  }

$terms = get_the_terms( $post->ID, 'category-solution' );
$services_links = array();
if($terms) {
	 foreach ( $terms as $term ) {
	   	$services_links[] = $term->slug;
	 }
	 $services = join( ", ", $services_links );
	 } else {
      $services='';
    }

$terms = get_the_terms( $post->ID, 'category-region' );
$country_links = array();
  if($terms) {
	 foreach ( $terms as $term ) {
	   	$country_links[] = $term->slug;
	 }
	 $country = join( ", ", $country_links );
	 } else {
      $country='';
    }
?>
<div class="summary">
    <h1>Contact your local specialist</h1>

    <form action="/find-an-expert" method="post">
                <label>
                    <span>Select a Country</span>
                <select name="country">
                    <option value="">Select a Country</option>
          <?php 
            $args = array( 'taxonomy' => 'category-region' );
            $terms = get_terms('category-region', $args);
            $x=0;
            foreach($terms as $term) : ?>
                    <?php if($term->parent != 0) :?><option <?php if(in_array($term->slug, $country_links) && $x==0) {$x=1; echo 'selected="selected" ';} ?>value="<?php echo $term->slug; ?>"><?php echo $term->name; ?></option><?php endif; ?>
          <?php  endforeach; ?>
                </select>
                </label>
                <label>
                    <span>Select a Sector</span>
                <select name="sector">
                    <option value="">Select a Sector</option>
          <?php 
            $args = array( 'taxonomy' => 'category-sector' );
            $terms = get_terms('category-sector', $args);
            $x=0;
            foreach($terms as $term) : ?>
                    <option <?php if(in_array($term->slug, $sector_links) && $x==0) {$x=1; echo 'selected="selected" ';} ?>value="<?php echo $term->slug; ?>"><?php echo $term->name; ?></option>
          <?php  endforeach; ?>
                </select>
                </label>
                <label>
                    <span>Select a Solution</span>
                <select name="service">
                    <option value="">Select a Service</option>
          <?php 
            $args = array( 'taxonomy' => 'category-solution', 'hide_empty' => false, 'parent' => 0 );
            $terms = get_terms('category-solution', $args);
            $x=0;
            foreach($terms as $term) : ?>
                    <option <?php if(in_array($term2->slug, $services_links) && $x==0) {$x=1; echo 'selected="selected" ';} ?>value="<?php echo $term->slug; ?>"><?php echo $term->name; ?></option>
            <?php $args = array( 'taxonomy' => 'category-solution', 'hide_empty' => false, 'parent' => $term->term_id );
                $terms2 = get_terms('category-solution', $args);
                $x=0;
                foreach($terms2 as $term2) : ?>
                     <option <?php if(in_array($term2->slug, $services_links) && $x==0) {$x=1; echo 'selected="selected" ';} ?>value="<?php echo $term2->slug; ?>"><?php echo "-".$term2->name; ?></option>
                <?php  endforeach; ?>
            <?php  endforeach; ?>
                </select>
                </label>
                <input type="submit" name="find-expert" value="Search" class="button"/>
     </form>


</div>