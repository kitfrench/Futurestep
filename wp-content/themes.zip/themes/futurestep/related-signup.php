<aside class="summaries related-content">
    <div class="summary-group">
        <h1>Sign up to hear more</h1>
        <p>Receive updates on white papers, articles, and other valuable thought leadership resources covering all
            facets of talent acquisition and management.</p>
        <a href="mailto:marketing@futurestep.com?Subject=Please%20register%20me%20for%20the%20newsletter"
           title="View all new and events" class="button">Sign up</a>
    </div>
</aside>